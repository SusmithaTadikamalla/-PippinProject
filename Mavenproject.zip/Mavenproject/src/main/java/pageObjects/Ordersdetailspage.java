package pageObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Ordersdetailspage 
{

	public WebDriver driver;
	
	//By order= By.cssSelector("span.css-30qmrf");
//	By order = By.cssSelector("[id='mat-radio-15']");
	
	/*List<WebElement> options = driver.findElements(By.cssSelector("span.css-30qmrf"));
	for(WebElement option : options)
	{
		if (option.getText().equalsIgnoreCase("Full Search"))
		{
			option.click();
			break;
		}
	}*/

	//WebElement product = driver.findElement(By.xpath("//span[@id='span.css-30qmrf']"));
	By product = By.xpath("//*[@id='mat-radio-15']/label/div[2]");
	By address = By.cssSelector("[id='Property_First_Name']");
	By clientReference = By.cssSelector("[id='Property_Order_Number']");
	By uploadDocument = By.cssSelector("button.btn.btn-primary.css-bnepv4");
	By property = By.cssSelector("[id='search-box']");
	By continueButton = By.cssSelector("button.btn.btn-primary.css-1qdd7d0");
	
	
	
	public Ordersdetailspage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}


	public WebElement getProduct()
	{
		return driver.findElement(product);
		
		
	}
	
	public WebElement getAddress()
	{
		return driver.findElement(address);
		
		
	}
	
	public WebElement getClientReference()
	{
		return driver.findElement(clientReference);
		
		
	}
	
	public WebElement getUploadDocuments()
	{
		return driver.findElement(uploadDocument);
		
		
	}
	
	public WebElement getProperty()
	{
		return driver.findElement(property);
		
		
	}
	
	public WebElement getContinueButton()
	{
		return driver.findElement(continueButton);
		
		
	}
}
