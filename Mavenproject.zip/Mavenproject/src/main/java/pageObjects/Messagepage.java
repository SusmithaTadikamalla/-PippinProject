package pageObjects;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Messagepage {
	
	public WebDriver driver;
	By orderNumber = By.cssSelector("input#Order_ID");
	By message = By.cssSelector("input#ordDetBtnSendMsg");
	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	Date date = new Date();
	String presentDate = dateFormat.format(date);
	By sendMessage = By.cssSelector("textarea#msg-area");
	By sendButton = By.cssSelector("input#msgSend");
	By menuButton = By.cssSelector("i.material-icons.css-p4x832");
	By logoutButton = By.xpath("//*[text() = 'Logout']");
	
	public Messagepage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}

	
	
	public WebElement getMessage()
	{
		return driver.findElement(message);	
		
	}
	
	
	public WebElement getOrderNumber()
	{
		return driver.findElement(orderNumber);
			
	}
	
	
	public String getPresentDate()
	{
		return presentDate;	

	}
	
	public WebElement getsendMessage()
	{
		return driver.findElement(sendMessage);

	}
	public WebElement getSendButton()
	{
		return driver.findElement(sendButton);

	}
	public WebElement getMenuButton()
	{
		return driver.findElement(menuButton);

	}
	
	public WebElement getLogoutButton()
	{
		return driver.findElement(logoutButton);

	}
}
