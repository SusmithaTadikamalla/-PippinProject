package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Placeneworderpage {
	public WebDriver driver;
	
	By terms = By.cssSelector("[id='mat-checkbox-1-input']");
	By submit = By.cssSelector("button.btn.btn-primary");
	public Placeneworderpage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}

	
	public WebElement getPlaceNewOrder()
	{
		return driver.findElement(terms);
		
		
	}
	
	public WebElement getSubmit()
	{
		return driver.findElement(submit);
		
		
	}
}
