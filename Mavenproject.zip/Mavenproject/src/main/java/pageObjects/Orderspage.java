package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Orderspage {

	public WebDriver driver;
	By order = By.xpath("//*[text() = 'Place Order']");


	
	public Orderspage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}


	public WebElement placeOrder()
	{
		return driver.findElement(order);
	}
	
	
}
