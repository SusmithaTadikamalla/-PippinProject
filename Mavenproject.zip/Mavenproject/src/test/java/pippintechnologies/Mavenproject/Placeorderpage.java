package pippintechnologies.Mavenproject;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import pageObjects.Loginpage;
import pageObjects.Orderspage;
import resources.Base;

public class Placeorderpage extends Base{

	@Test(priority=2)
	public void basePageNavigation() throws IOException
	{
		driver = initializeDriver();
	//	driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		//driver.findElement(By.cssSelector("[value='RoundTrip']")).click();
		
		
	//	Orderspage order = new Orderspage(driver);
	//	order.placeOrder().click();
	}
	
	
}
