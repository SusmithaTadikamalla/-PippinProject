package pippintechnologies.Mavenproject;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObjects.Loginpage;
import pageObjects.Messagepage;
import pageObjects.Ordersdetailspage;
import pageObjects.Orderspage;
import pageObjects.Placeneworderpage;
import resources.Base;

//import org.junit.Test;

public class Homepage extends Base{

	@Test(dataProvider="getData" , priority=1)
	public void basePageNavigation(String email,String password) throws IOException
	{
		driver = initializeDriver();
		driver.get("https://demo.pippintitle.com/");
		driver.manage().window().maximize();

		Loginpage loginPage= new Loginpage(driver);
		loginPage.getEmail().sendKeys(email);
		loginPage.getPassword().sendKeys(password);
		loginPage.getLogin().click();

	}

	@Test(priority=2)
	public void placeOrder() throws IOException
	{
		
		Orderspage order = new Orderspage(driver);
		order.placeOrder().click();
	
	}
	
	@Test(priority=3)
	public void orderDetails() throws IOException, InterruptedException
	{
		
		Ordersdetailspage orderDetails = new Ordersdetailspage(driver);

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	//wait time as default for all test cases
		System.out.println(orderDetails.getProduct().getText());
		Thread.sleep(5000);
		orderDetails.getProduct().click();
		orderDetails.getAddress().sendKeys("Susmith TNVK");
		orderDetails.getClientReference().sendKeys("SusmithaTNVK_16_04_1995");
		orderDetails.getUploadDocuments().sendKeys("D:\\PHOTOS\\pro.txt");
		Actions a = new Actions(driver);
		orderDetails.getProperty().sendKeys("3485 Wineville");
		a.moveToElement(orderDetails.getProperty()).sendKeys("3485 Wineville").keyDown(Keys.ARROW_DOWN).keyDown(Keys.ARROW_DOWN).doubleClick().build().perform();
		orderDetails.getContinueButton().click();
	}
	
	@Test(priority=4)
	 public void placeNewOrder()
	 {
		Placeneworderpage placeNewOrder = new Placeneworderpage(driver);
		placeNewOrder.getPlaceNewOrder().click();
		placeNewOrder.getSubmit().click();
	 }
	
	@Test(priority=5)
	
		public void Message()
		{
			Messagepage message = new Messagepage(driver);
			String orderNumber = message.getOrderNumber().getText();
			message.getMessage().click();
			String presentDate = message.getPresentDate();
			message.getsendMessage().sendKeys("Susmitha " +orderNumber  +presentDate);
			message.getSendButton().click();
			message.getMenuButton().click();
			message.getLogoutButton().click();
			driver.close();
		}
	
	@DataProvider
	
	public Object[][] getData()
	{
		//row stands for how many different data types should run
		//column stands for how many values per each test
		Object[][] data = new Object[1][2];
		//0th row
		data[0][0]="pippintitle_demotest@mailinator.com";
		data[0][1]="DemoTest#567#";
		return data;
	}
	
}
